# "Finite-time blow-up for the real-valued defocusing energy-supercritical NLW"
# M. Cadiot, A. D. Ionescu and S. Palasek.
# Computer-assisted profile validation; references below are to Sections 4-5 of this paper.
# The variables W and ω represent the approximate objects W̄ and ω̄ of Section 4.4.
# Theorem 5.11 supplies the analytic profile used in Proposition 2.4.
#
# Coefficients: the paper uses Σ_k w_k T_k; RadiiPolynomial uses a_0 + 2Σ_{k≥1} a_k T_k.
# Thus w_0 = a_0, w_k = 2a_k for k ≥ 1, and the package norm has weights 1,2ν,2ν²,... .
# The saved W satisfies a_{-n,k} = conj(a_{n,k}) and contains only odd Fourier modes.

# Use the environment supplied with this proof folder.
using Pkg ; Pkg.activate(@__DIR__)
Pkg.instantiate()
using RadiiPolynomial, IntervalArithmetic, LinearAlgebra, JLD2

# Outward rounding encloses each BigFloat interval in Float64.
function big2float(U)
    Ur = interval.(Float64.(inf.(real.(U)),RoundDown),Float64.(sup.(real.(U)),RoundUp))
    Ui = interval.(Float64.(inf.(imag.(U)),RoundDown),Float64.(sup.(imag.(U)),RoundUp))
    return complex(Ur,Ui)
end

# Chebyshev weights in the package convention; isometric to the paper's ℓ¹_ν norm.
function weight_nu(ν,N)
    w = interval.(zeros(N+1))
    w[1] = interval(1)
    for i=1:N
        w[i+1] = interval(2)*ν^interval(i)
    end
    return w
end

# Weighted column sums; their maximum bounds the operator norm in (5.4).
# Scale entries before taking complex moduli to limit intermediate magnitudes.
function norm_cols(B,w1,w2)
    return vec(sum(abs.(w1.*B./w2'), dims=1))
end

# Bound ‖π^{>M}a‖, using the rectangular projection of Section 4.4.
# Restrict M to the available support before calling tail.
function norm_outside(a,M,X)
    Ma = order(space(a))
    return norm(tail(a, (min(M[1],Ma[1]), min(M[2],Ma[2]))), X)
end

# Equations (5.7)-(5.8): bound the finite columns of Λ_n⁻¹ and ∂ωΛ_n Λ_n⁻¹.
# Upper triangularity (5.3) makes these also columns of the infinite inverse.
# The floating matrix X is validated through ε = ‖I-Λ_n X‖, followed by a Neumann bound.
function columns_Λinv(n,ω,K,ν,α,d)
    # Entries of Lemma 4.2 and (5.1), in the package coefficient convention.
    s = interval(n)*ω
    a = (α + interval(im)*s)/interval(2) ; b = (α + interval(1) + interval(im)*s)/interval(2)
    γ = -(a+b) ; γ′ = interval(d-1) + γ
    ks = interval.(0:K)
    diag = interval(4)*(ks .+ a).*(ks .+ b)
    ddiag = interval(2)*interval(im)*interval(n)*(interval(2)*ks .+ α .+ I"0.5" .+ interval(im)*s)
    γm = (γ + γ′)/interval(2) ; γd = (γ - γ′)/interval(2)
    # Construct X from midpoint entries; all ensuing defect bounds use intervals.
    Λm = zeros(ComplexF64, K+1, K+1)
    γf = mid(γ) ; γ′f = mid(γ′)
    for k = 0:K
        Λm[k+1,k+1] = mid(diag[k+1])
        for j = 0:k-1
            Λm[j+1,k+1] = -8*k*(iseven(k-j) ? γf : γ′f)
        end
    end
    X = Matrix(inv(UpperTriangular(Λm)))
    Λm = nothing
    # Accumulate column norms of I-Λ_n X, X, and ∂ωΛ_n X.
    sE = interval.(zeros(K+1)) ; sX = interval.(zeros(K+1)) ; sdX = interval.(zeros(K+1))
    νinv = interval(1)/ν ; c8 = interval(8) ; c8in = interval(8*n)*interval(im)
    Threads.@threads for k = 0:K
        # Rank-two structure (Lemma 4.2): c1 = Σ_{l>j} lX_lk, c2 = Σ_{l>j} (-1)^l lX_lk.
        c1 = complex(interval(0),interval(0)) ; c2 = complex(interval(0),interval(0)) ; pw = interval(1)
        e = interval(0) ; x_ = interval(0) ; dx = interval(0)
        for j = k:-1:0
            x = interval(X[j+1,k+1])
            sgn = iseven(j) ? interval(1) : interval(-1)
            E = (j == k ? interval(1) : interval(0)) - (diag[j+1]*x - c8*(γm*c1 + γd*sgn*c2))
            dΛX = ddiag[j+1]*x + c8in*c1
            # pw = ν^(j-k); the row-zero factor converts it to w_j/w_k.
            wr = (j == 0 && k >= 1) ? pw/interval(2) : pw
            e += wr*abs(E) ; x_ += wr*abs(x) ; dx += wr*abs(dΛX)
            c1 += interval(j)*x ; c2 += sgn*interval(j)*x
            pw = pw*νinv
        end
        sE[k+1] = e ; sX[k+1] = x_ ; sdX[k+1] = dx
    end
    # If ε < 1, Λ_n⁻¹ = X(I-E)⁻¹ with E = I-Λ_n X.
    ε = maximum(sE)
    sup(ε) < 1 || error("The finite inverse defect is not smaller than one for mode $n.")
    λ = sX .+ maximum(sX)*ε/(interval(1)-ε) ; λ′ = sdX .+ maximum(sdX)*ε/(interval(1)-ε)
    # Return the inverse-error bound as well, for the direct products in (5.26).
    return λ, λ′, ε, X, maximum(sX)*ε/(interval(1)-ε)
end

# Laurent coefficients of ν^(-s)(c_0 + 2Σ_{k≥1}c_k T_k), on |ζ|=ν.
# The coefficient at j is ν^(j-s)c_|j|, for -K ≤ j ≤ K.
ellipse(c,K,s) = Sequence(Fourier(K,interval(1)), [ν^interval(j-s)*c[abs(j)+1] for j = -K:K])
# First term of (5.26): bound ‖M_{V_{≤mE}} X_n e_k‖ / ‖e_(n,k)‖.
# FV stores the precomputed FFTs of the retained Fourier modes of V.
function col_MV(x,n,k)
    L = fft_size(Fourier(k+NV2,interval(1)))
    Fx = fft(ellipse(interval.(x),k,k), L)
    s = interval(0)
    # V has only even Fourier modes; output mode n+m carries weight νθ^|n+m|.
    for m = filter(iseven, -mE:mE)
        c = coefficients(ifft!(Fx.*FV[(m,L)], Fourier(k+NV2,interval(1))))
        s += νθ^interval(abs(n+m))*(abs(c[k+NV2+1]) + interval(2)*sum(abs.(c[k+NV2+2:end])))
    end
    # ellipse already includes ν^(-k); divide by the remaining input-column weight.
    return s/(νθ^interval(n)*interval(k == 0 ? 1 : 2))
end

# --- Stored approximation and parameters: Section 4.4, Tables 2-3 ---

# JLD2 contains W, ω, d, p; W and ω use BigFloat intervals in the package convention.
file = "approximate_solution_d6_p7.jld2"
sol = load(joinpath(@__DIR__, file))
d = Int(sol["d"]) ; p = Int(sol["p"])
(d,p) == (6, 7) || error("Saved data do not match this proof case.")
# Odd p preserves half-period antisymmetry; the dimension condition is (2.1).
if isodd(p) == false || d <= 2 + 4/(p-1)
    error("p = $p must be odd and d = $d must satisfy d > 2 + 4/(p-1)")
end
# NWs is the stored Fourier-Chebyshev order; keep it separate from the finite inverse size N.
NWs = order(space(sol["W"]))

# Tables 2-3: parameters for (d,p) = (6, 7).
NWs == (145, 600) || error("Saved approximation has the wrong Fourier-Chebyshev order.")
# N is the finite inverse size; K is the explicit inverse-column cutoff.
# Keep every stored mode in NW; 192-bit arithmetic is used for the residual.
# τ and mE select the direct column estimates (5.26).
N1 = 95 ; N2 = 1000 ; K1 = 205 ; K2 = 8000 ; νs = "1.1" ; νθs = "1.01" ; NW1 = NWs[1] ; NW2 = NWs[2] ; prec = 192 ; τ = 0.8 ; mE = 30

# V = π^{≤N+(10,10)}(pW^(p-1)); see Lemma 5.2 and the proof of Theorem 5.11.
NV1 = N1+10 ; NV2 = N2+10
# Enclose the decimal weights; Section 5.2 constructs their BigFloat counterparts.
ν = parse(Interval{Float64}, νs) ; νθ = parse(Interval{Float64}, νθs)
setprecision(prec)
# Odd cutoffs preserve the odd-mode indexing; analytic tails require K strictly beyond N.
if iseven(N1)||iseven(K1)||iseven(NW1)
    error("N1, K1 and NW1 have to be odd : only the odd Fourier modes are used")
end
if (K1 <= N1)||(K2 <= N2)
    error("The sizes are not compatible : K1 > N1 and K2 > N2 are needed")
end
# α = 2/(p-1), and g = Re γ′_n in (4.8) and (5.9).
α = interval(2)/interval(p-1)
g = interval(d) - α - I"1.5"

# Spaces: θ is Fourier, x = 2ρ²-1 is Chebyshev (Sections 4.2-4.4).
# SW holds W; S is the finite inverse block; SV holds the projected potential V.
SW = Fourier(NW1,interval(1))⊗Chebyshev(NW2)
S = Fourier(N1,interval(1))⊗Chebyshev(N2)
SV = Fourier(NV1,interval(1))⊗Chebyshev(NV2)
# Retain the full polynomial supports of pW^(p-1) and W^p (Sections 5.2-5.3).
Sp1 = Fourier((p-1)*NW1,interval(1))⊗Chebyshev((p-1)*NW2)
Sp = Fourier(max(p*NW1,N1),interval(1))⊗Chebyshev(max(p*NW2,N2))
# Chebyshev space for one Fourier mode, and the weighted norms used in (5.4).
SN = Chebyshev(N2)
ℓν = ℓ¹(GeometricWeight(ν))

# Project the saved approximation to SW; the proof may have NW outside N.
W_big = project(sol["W"], SW) ; ω_big = sol["ω"]
# Keep BigFloat inputs for Y and enclose them in Float64 for the operator bounds.
W = big2float(W_big) ; ω = interval(Float64(inf(ω_big),RoundDown),Float64(sup(ω_big),RoundUp))

println("CONSTRUCTIVE EXISTENCE PROOF of a discretely self-similar profile for NLW with (d,p) = ($d,$p)")
println("    ω ≈ $(mid(ω)),  NW = ($NW1,$NW2),  N = ($N1,$N2),  K = ($K1,$K2),  ν = $(mid(ν)),  νθ = $(mid(νθ)),  $prec bits")

# Section 5.2: residual bound Y (Lemma 5.1, (5.5)).

# Evaluate polynomial products on |z| = νθ, |ζ| = ν, using interval FFTs.
# The Laurent coefficients then carry the geometric weights of Section 4.3.
# BigFloat arithmetic controls FFT error and avoids underflow in the residual norm.
function to_ellipse(a, νθ, ν)
    # Lift Fourier-Chebyshev coefficients to weighted Laurent coefficients on the torus.
    # RadiiPolynomial uses a₀ + 2∑ aₖTₖ; the Laurent coefficient at ±k is aₖ.
    M1, M2 = order(space(a))
    wθ = [inv.(reverse(cumprod(fill(νθ, M1)))) ; one(νθ) ; cumprod(fill(νθ, M1))]   # νθ^n for -M₁ ≤ n ≤ M₁.
    wx = [inv.(reverse(cumprod(fill(ν, M2)))) ; one(ν) ; cumprod(fill(ν, M2))]   # ν^j for -M₂ ≤ j ≤ M₂.
    b = Sequence(Fourier(M1,interval(1))⊗Fourier(M2,interval(1)), zeros(eltype(a), (2*M1+1)*(2*M2+1)))
    for n = -M1:M1, j = -M2:M2
        b[(n,j)] = wθ[n+M1+1]*wx[j+M2+1]*a[(n,abs(j))]
    end
    return b
end
function from_ellipse(b, νθ, ν, s)
    # Recover Chebyshev coefficients from the nonnegative Laurent indices.
    # The products are real: reconstruct negative Fourier modes by conjugation.
    M1, M2 = order(s) ; Mb1, Mb2 = order(space(b))
    wθ = [one(νθ) ; cumprod(fill(νθ, M1))] ; wx = [one(ν) ; cumprod(fill(ν, M2))]
    a = Sequence(s, zeros(eltype(b), (2*M1+1)*(M2+1)))
    for n = 0:min(M1,Mb1), k = 0:min(M2,Mb2)
        a[(n,k)] = b[(n,k)]/(wθ[n+1]*wx[k+1])
        n > 0 && (a[(-n,k)] = conj(a[(n,k)]))
    end
    return a
end
function norm_ellipse(b, νθ)
    # Enclose the Section 4.3 norm from the weighted Laurent coefficients.
    # For n < 0, multiply by νθ^(2|n|) to restore the weight νθ^|n|.
    M1, M2 = order(space(b))
    s = zero(real(eltype(b)))
    for n = -M1:M1
        t = abs(b[(n,0)])
        for j = 1:M2
            t += interval(2)*abs(b[(n,j)])
        end
        s += n >= 0 ? t : t*νθ^(-2*n)
    end
    return s
end
# Outward conversion of BigFloat interval endpoints.
f64(x) = interval(Float64(inf(x),RoundDown),Float64(sup(x),RoundUp))
# Parse the same decimal weights at BigFloat precision.
# Starting from Float64 intervals would unnecessarily widen every FFT input.
νb = parse(Interval{BigFloat}, νs) ; νθb = parse(Interval{BigFloat}, νθs)
ℓθν_big = ℓ¹(GeometricWeight(νθb),GeometricWeight(νb))

# Use the full support pNW to avoid aliasing in both polynomial products (Lemma 5.1).
W_e = to_ellipse(W_big, νθb, νb)
W_grid = fft(W_e, fft_size(Fourier(p*NW1,interval(1))⊗Fourier(p*NW2,interval(1))))
# Full derivative potential pW^(p-1).
V_big = interval(p)*from_ellipse(ifft!(W_grid.^(p-1), Fourier((p-1)*NW1,interval(1))⊗Fourier((p-1)*NW2,interval(1))), νθb, νb, Sp1)
# Full nonlinearity W^p.
Wp_big = from_ellipse(ifft!(W_grid.^p, Fourier(p*NW1,interval(1))⊗Fourier(p*NW2,interval(1))), νθb, νb, Sp)
W_e = nothing ; W_grid = nothing ; GC.gc()

# Form the complete residual Λ(ω)W + W^p of (4.13), in x = 2ρ² - 1.
# Keep every generated mode, including the nonlinear tail beyond NW (Lemma 5.1).
# Coordinate x in the Chebyshev basis.
x = Sequence(Fourier(0,interval(1))⊗Chebyshev(1), [interval(0) ; I"0.5"])
∂xW = differentiate(W_big,(0,1)) ; ∂xxW = differentiate(∂xW,(0,1)) ; ∂θW = differentiate(W_big,(1,0)) ; ∂θθW = differentiate(W_big,(2,0)) ; ∂θxW = differentiate(W_big,(1,1))
αb = interval(BigFloat,2)/interval(BigFloat,p-1)   # Enclose α = 2/(p-1) at the working precision.
ΛW_Wp_big = ω_big^2*∂θθW + (interval(2)*αb+interval(1))*ω_big*∂θW + αb*(αb+interval(1))*W_big - interval(4)*(interval(1) - x*x)*∂xxW - (interval(4*d) - (interval(4)*αb+interval(6))*(interval(1) + x))*∂xW + interval(4)*ω_big*(interval(1) + x)*∂θxW + Wp_big
# Frequency column from (5.1)-(5.2); the Fourier multiplier 𝒩² is -∂θ².
dΛW_big = interval(2)*ω_big*∂θθW + (interval(2)*αb+interval(1))*∂θW + interval(4)*(interval(1) + x)*∂θxW
# Phase condition of Section 4.3: Im W₁(x=1), evaluated in the Chebyshev convention.
# NW2 ≤ N2 in the three cases, so this agrees with the phase cutoff in (4.12).
ℓW = imag(Sequence(Chebyshev(NW2), W_big[(1,0:NW2)])(interval(1))) ; ℓW = f64(ℓW)

# Enclose full polynomial norms before converting to Float64.
# Lemma 5.2 uses V = π^{≤NV}(pW^(p-1)) and the separately bounded truncation error.
norm_W = f64(norm(W_big,ℓθν_big)) ; norm_pWp1 = f64(norm(V_big,ℓθν_big)) ; norm_𝒩²W = f64(norm(-∂θθW,ℓθν_big))
norm_pWp1_V = f64(norm_outside(V_big,(NV1,NV2),ℓθν_big))
# The frequency-column tail enters Z₁,₁; it is zero when NW ≤ N (Lemma 5.2).
norm_dΛW_out = f64(norm_outside(dΛW_big,(N1,N2),ℓθν_big))
# Lemma 5.1: Y bounds the full X-norm of F, including the phase residual.
norm_ΛW_Wp = f64(norm(ΛW_Wp_big,ℓθν_big))
Y = abs(ℓW) + norm_ΛW_Wp

# Retain outward Float64 enclosures of the arrays needed for Z₁ and Z₂.
V = big2float(project(V_big,SV)) ; dΛW = project(big2float(dΛW_big),S)
V_big = nothing ; Wp_big = nothing ; ΛW_Wp_big = nothing ; dΛW_big = nothing ; GC.gc()

println("‖W‖ = $norm_W ,  ‖pW^(p-1)‖ = $norm_pWp1 ,  ‖𝒩²W‖ = $norm_𝒩²W ,  ‖pW^(p-1) - V‖ = $norm_pWp1_V ,  ‖π^{>N}∂ωΛ W‖ = $norm_dΛW_out")
println("Bound Y : Y = $Y")

# Enclose ‖W^m‖ for Lemma 5.8 by finite interval FFTs on the same torus.
# Store norm_Wm[m+1] ≥ ‖W^m‖, with ‖W^0‖ = 1.
norm_Wm = [interval(1) ; norm_W]
W_grid_m = fft(big2float(to_ellipse(W_big, νθb, νb)), fft_size(Fourier((p-2)*NW1,interval(1))⊗Fourier((p-2)*NW2,interval(1))))
for m = 2:p-2
    # Also use the Banach algebra bound ‖W^m‖ ≤ ‖W‖^m.
    push!(norm_Wm, min(norm_ellipse(ifft!(W_grid_m.^m, Fourier(m*NW1,interval(1))⊗Fourier(m*NW2,interval(1))), νθ), norm_W^m))
end
W_grid_m = nothing ; GC.gc()

# Section 5.3.1: infinite-tail constants κ, κ′ and κ′′ (Lemmas 5.7 and 5.9).

# β is defined in (5.10); θ₁, θ₂, θ₃, θ₃′ control the large-Chebyshev tail in (5.21).
γp_K1 = sqrt(g^2 + interval(K1)^2*ω^2)
γp_K1p2 = sqrt(g^2 + interval(K1+2)^2*ω^2)
β_K1 = interval(4)*(interval(2*(d-1)) + (ν-interval(1))*γp_K1)/(ν-interval(1))^2
β_K1p2 = interval(4)*(interval(2*(d-1)) + (ν-interval(1))*γp_K1p2)/(ν-interval(1))^2
θ1 = (interval(1)+ν)^2/(ν^2*(ν-interval(1))*interval(K2+1))*(γp_K1 + (interval(1)+ν)*(interval(4)*interval(K2)^2 + interval(K1)^2*ω^2)/(interval(16)*interval(K2-1)))
θ2 = (interval(1)+ν)^2*(interval(4)*interval(K2+1)^2 + interval(K1)^2*ω^2)/(interval(8)*ν*(ν-interval(1))*interval(K2)*interval(K2+1))
θ3 = interval(1)/(interval(4)*interval(K2-1)^2)*(interval(1) + β_K1/interval(K2+1))
θ3′ = interval(1)/interval(K2+1)*(interval(1) + interval(4)/(ν-interval(1)) + β_K1/interval(K2-1))
# Lemma 5.5: high-Fourier bounds η/n² and η′, with constants (5.20).
η = interval(1)/ω^2*(interval(1) + β_K1p2/(interval(K1+2)*ω))
η′ = interval(1)/ω*(interval(2) + interval(4)/(ν-interval(1)) + interval(2)*β_K1p2/(interval(K1+2)*ω))

# Check (5.11)-(5.12), the transfer-contraction hypotheses of Lemma 5.3.
# Here s = (K₁+2)ω is the first omitted positive Fourier frequency.
sK = interval(K1+2)*ω
H_radial = interval(4*(d-1))/((ν-interval(1))*interval(K2-1)) + sqrt(interval(1) + interval(4)*g/interval(K2-1) + interval(4*(d-1))*g/interval(K2-1)^2 + α*(α+interval(1))*g/interval(K2-1)^3)
H_fourier = interval(4*(d-1))/((ν-interval(1))*sK) + sqrt(interval(1) + I"2.6"*g/sK + interval(4*(d-1))*g/sK^2 + I"2.6"*α*(α+interval(1))*g/sK^3)
H = (sup(H_radial) <= inf((interval(1)+ν)/interval(2)))&&(sup(H_fourier) <= inf((interval(1)+ν)/interval(2)))&&(K2 > N2)&&(K1 > N1)
H || error("Transfer hypotheses (5.11)-(5.12) were not verified.")

# Only positive odd n are needed; the negative blocks are their conjugates.
# Initialize the exterior bounds with Lemma 5.5 for |n| > K₁.
# For Z₁,₂, use (5.6) by default and the sharper product bound (5.26) above threshold τ.
cZ = norm_pWp1 + I"0.5"/νθ
# Norm of the Fourier tail of V outside |m| ≤ mE.
V_r = sum((νθ^interval(abs(m))*norm(Sequence(Chebyshev(NV2), V[(m,0:NV2)]), ℓν) for m = filter(iseven, -NV1:NV1) if abs(m) > mE), init = interval(0))
# Cache interval FFTs for the retained Fourier modes of V in (5.26).
FV = Dict((m,L) => fft(ellipse(V[(m,0:NV2)],NV2,0), L) for m = filter(iseven, -mE:mE) for L = unique([fft_size(Fourier(k+NV2,interval(1))) for k = 0:K2]))
# Initialize κ, κ′, κ′′ with the high-Fourier bounds of Lemmas 5.5 and 5.9.
κ = η/interval(K1+2)^2 ; κ′ = η′ ; κ′′ = η ; ε_max = interval(0)
# κ_r covers columns handled by (5.6); Z1_2E covers those handled by (5.26).
κ_r = κ ; Z1_2E = interval(0)
for n = 1:2:K1
    global κ, κ′, κ′′, ε_max, κ_r, Z1_2E
    # Enclose λ, λ′ and the inverse defect ε on k = 0,...,K₂, using (5.7)-(5.8).
    λ, λ′, ε, X, δ = columns_Λinv(n,ω,K2,ν,α,d)
    ε_max = maximum([ε_max ε])
    # Exterior columns begin at k₀; select those needing the sharper estimate (5.26).
    k0 = n <= N1 ? N2+1 : 0
    kE = filter(k -> sup(cZ*λ[k+1]) > τ, k0:K2)
    cE = interval.(zeros(length(kE)))
    # In (5.26), add discarded V modes, potential truncation and the phase term (only n=1).
    # δ bounds the Neumann correction from X to Λₙ⁻¹.
    for i = eachindex(kE)
        cE[i] = col_MV(X[1:kE[i]+1,kE[i]+1], n, kE[i]) + (V_r + norm_pWp1_V + (n == 1 ? I"0.5"/νθ : interval(0)))*λ[kE[i]+1] + norm_pWp1*δ
    end
    X = nothing
    # Lemma 5.6 controls every k > K₂ using the two columns K₂-1 and K₂.
    λK = θ1*λ[K2]+θ2*λ[K2+1]+θ3
    κ_r = maximum([κ_r ; λ[setdiff(k0:K2,kE) .+ 1] ; λK]) ; Z1_2E = maximum([Z1_2E ; cE])
    λ = [λ[k0+1:end] ; λK] ; λ′ = [λ′[k0+1:end] ; θ1*λ′[K2]+θ2*λ′[K2+1]+interval(n)*θ3′]
    # Maximize over the finite rectangle and the infinite Chebyshev tail.
    κ = maximum([κ ; λ]) ; κ′ = maximum([κ′ ; λ′]) ; κ′′ = maximum([κ′′ ; interval(n)^2*λ])

end
println("Defect of the approximate inverses of Λ_n : ε ≤ $ε_max")
println("κ = $κ ≥ ‖Λ^{-1}π^{>N}‖ ,  κ′ = $(κ′) ≥ ‖∂ωΛ Λ^{-1}π^{>N}‖ ,  κ′′ = $(κ′′) ≥ ‖𝒩²Λ^{-1}π^{>N}‖")

# Lemma 5.2: combine directly bounded columns with the product bound (5.6).
# Check Z₁,₂ before constructing the large finite inverse.
Z1_2 = maximum([Z1_2E cZ*κ_r])
println("Bound Z_{1,2} : Z1_2 = $Z1_2")
# Check the exterior bound before allocating the finite inverse.
sup(Z1_2) < 1 || error("The exterior bound Z1_2 is not smaller than one.")

# Finite inverse: Section 4.4 and the proof of Theorem 5.11.

# Use W_{±n}=a_n±i b_n for positive odd n (Remark 4.6).
# ind indexes signed complex modes; ia and ib index the real coordinates.
# The real matrix has order (N1+1)(N2+1)+1, including the frequency coordinate.
d2 = N2+1 ; dd = (N1+1)*d2
ind(n) = div(n+N1,2)*d2 .+ (2:d2+1)
ia(n) = div(n-1,2)*2*d2 .+ (2:d2+1) ; ib(n) = ia(n) .+ d2

# w contains the complex-coordinate weights for the norm on X; see (5.4).
w = [interval(1) ; vec([νθ^interval(abs(n))*wk for wk = weight_nu(ν,N2), n = -N1:2:N1])]
# wr is used only to scale the floating-point inverse; certification uses w.
wr = [interval(1) ; vec([νθ^interval(n)*wk for wk = [weight_nu(ν,N2) ; weight_nu(ν,N2)], n = 1:2:N1])]

# Multiplication by each even Fourier mode of V, retaining every generated radial mode.
# Its range has Chebyshev degree N2+NV2; the excess feeds Z_{1,1} (Lemma 5.2).
MV = Dict(k => project(Multiplication(Sequence(Chebyshev(NV2), V[(k,0:NV2)])), SN, Chebyshev(N2+NV2)) for k = filter(iseven, -NV1:NV1))

# Build Λ_n=L0+i n ω L1−n²ω² I and ∂ωΛ_n=i n L1−2n²ω I; see (5.1).
# Differential operators provide interval enclosures of the finite matrices.
Id = LinearOperator(SN, SN, interval.(1.0*I[1:N2+1, 1:N2+1]))
# The RadiiPolynomial coefficient 1/2 represents the polynomial x.
xc = Sequence(Chebyshev(1), [interval(0) ; I"0.5"])
D = project(Derivative(1), SN, SN, Interval{Float64}) ; D2 = D*D
Mx = project(Multiplication(xc), SN, SN) ; Mx2 = project(Multiplication(xc*xc), SN, SN)
L0 = -interval(4)*(D2 - Mx2*D2) - (interval(4*d) - interval(4)*α - interval(6))*D + (interval(4)*α + interval(6))*Mx*D + α*(α+interval(1))*Id
L1 = interval(4)*(D + Mx*D) + (interval(2)*α + interval(1))*Id
L0N = coefficients(L0) ; L1N = coefficients(L1) ; IdN = interval.(1.0*I[1:d2, 1:d2])
dΛN(n) = (interval(im)*interval(n))*L1N - (interval(2)*interval(n)^2*ω)*IdN
# Evaluate the first Fourier harmonic at x=1 for the phase row (4.13).
ξ = project(Evaluation(interval(1)), SN, ParameterSpace(), Interval{Float64})

# Assemble the finite derivative with V replacing pW^(p−1); see (5.2).
# Process two positive Fourier modes at a time to limit temporary storage.
blkp = [n0:2:min(n0+2,N1) for n0 = 1:4:N1]
rows_r(ns, withℓ) = vcat(withℓ ? [1] : Int[], [vcat(ia(n), ib(n)) for n = ns]...)
# Complex rows of DF_V: optional phase row, then the requested Fourier modes.
function DN_modes(ns, withℓ)
    o = withℓ ? 1 : 0
    B = zeros(Complex{Interval{Float64}}, o + length(ns)*d2, dd+1)
    # ℓ(h)=(h_1(1)−h_{−1}(1))/(2i); only modes ±1 enter this row.
    if withℓ
        B[1,ind(1)] = -I"0.5"*interval(im)*vec(coefficients(ξ)) ; B[1,ind(-1)] = I"0.5"*interval(im)*vec(coefficients(ξ))
    end
    for (i,n) = enumerate(ns)
        r = o + (i-1)*d2 .+ (1:d2)
        for m = filter(isodd, max(-N1,n-NV1):min(N1,n+NV1))
            B[r,ind(m)] = coefficients(MV[n-m])[1:d2,:]
        end
        B[r,ind(n)] += L0N + (interval(im)*interval(n)*ω)*L1N - (interval(n)*ω)^2*IdN
        # The ω column is ∂ωΛ W, as in (5.2).
        B[r,1] = dΛW[(n,0:N2)]
    end
    return B
end
# Convert conjugate-paired inputs to (a_m,b_m), then split each output into Re/Im.
# The corresponding blocks are D_{n,m}+D_{n,−m} and i(D_{n,m}−D_{n,−m}).
function real_rows(Bc, ns, withℓ)
    o = withℓ ? 1 : 0
    rc = o+1:size(Bc,1)
    Br = zeros(Interval{Float64}, o + 2*length(rc), dd+1)
    rre = vcat([o + (i-1)*2*d2 .+ (1:d2) for i = 1:length(ns)]...) ; rim = rre .+ d2
    for m = 1:2:N1
        S = Bc[:,ind(m)] + Bc[:,ind(-m)] ; Dm = Bc[:,ind(m)] - Bc[:,ind(-m)]
        if withℓ
            Br[1,ia(m)] = real.(S[1,:]) ; Br[1,ib(m)] = -imag.(Dm[1,:])
        end
        Br[rre,ia(m)] = real.(S[rc,:]) ; Br[rre,ib(m)] = -imag.(Dm[rc,:])
        Br[rim,ia(m)] = imag.(S[rc,:]) ; Br[rim,ib(m)] = real.(Dm[rc,:])
    end
    if withℓ
        Br[1,1] = real(Bc[1,1])
    end
    Br[rre,1] = real.(Bc[rc,1]) ; Br[rim,1] = imag.(Bc[rc,1])
    return Br
end

# Form a floating-point inverse; interval defect bounds certify it below.
# Diagonal weight scaling improves the balance of its entries.
BN = zeros(Float64, dd+1, dd+1)
for (i,ns) = enumerate(blkp)
    BN[rows_r(ns, i == 1),:] = mid.(real_rows(DN_modes(ns, i == 1), ns, i == 1))
    GC.gc()
end
wm = mid.(wr)
BN .= wm.*BN./wm'
# Invert in place to avoid a second full matrix, then undo the scaling.
BN = LinearAlgebra.inv!(lu!(BN))
BN .= BN.*wm'./wm
GC.gc()

# Extend the real inverse to the complex-linear A_N of Theorem 5.11.
# If (Tc)_{±m}=c_{a_m}±i c_{b_m}, then A_N e_n=(Tc_a−i Tc_b)/2 for n>0.
# Conjugation symmetry gives equal column norms for n and −n (Remark 4.6).
function A_cols(ns)
    ca = vcat([ia(n) for n = ns]...) ; cb = vcat([ib(n) for n = ns]...)
    Ca = interval.(BN[:,ca]) ; Cb = interval.(BN[:,cb])
    Z = zeros(Complex{Interval{Float64}}, dd+1, length(ca))
    Z[1,:] = (Ca[1,:] - interval(im)*Cb[1,:])/interval(2)
    for m = 1:2:N1
        A = Ca[ia(m),:] ; B = Ca[ib(m),:] ; A′ = Cb[ia(m),:] ; B′ = Cb[ib(m),:]
        Z[ind(m),:] = ((A + B′) + interval(im)*(B - A′))/interval(2)
        Z[ind(-m),:] = ((A - B′) - interval(im)*(B + A′))/interval(2)
    end
    return Z
end

# Z_{1,0}: finite defect I−DF_V A_N (Section 5.3, Lemma 5.2).
# Compute E=I−DN*BN in real row/column blocks, then recover complex column norms.
# The first block also contains the frequency column and the phase row.
Z1_0 = interval(0)
for (j,nsJ) = enumerate(blkp)
    global Z1_0
    o = j == 1 ? 1 : 0
    J = rows_r(nsJ, j == 1)
    # Local positions of the a and b columns in the current block J.
    pa = vcat([o + (q-1)*2*d2 .+ (1:d2) for q = 1:length(nsJ)]...) ; pb = pa .+ d2
    BNJ = interval.(BN[:,J])
    s = interval.(zeros(length(pa))) ; sω = interval(0)
    for (i,nsR) = enumerate(blkp)
        oR = i == 1 ? 1 : 0
        E = -(real_rows(DN_modes(nsR, i == 1), nsR, i == 1)*BNJ)
        # Add the identity only on matching row and column blocks.
        if i == j
            for q = 1:length(J)
                E[q,q] += interval(1)
            end
        end
        # Contribution of the scalar phase output to the complex column norms.
        if oR == 1
            s .+= sqrt.(E[1,pa].^2 .+ E[1,pb].^2)./interval(2)
            if o == 1
                sω += abs(E[1,1])
            end
        end
        # Recover both signed output modes and sum their weighted complex moduli.
        for (q,m) = enumerate(nsR)
            rre = oR + (q-1)*2*d2 .+ (1:d2) ; rim = rre .+ d2 ; wmod = w[ind(m)]
            A = E[rre,pa] ; B = E[rim,pa] ; A′ = E[rre,pb] ; B′ = E[rim,pb]
            s .+= vec(sum(wmod.*(sqrt.((A .+ B′).^2 .+ (B .- A′).^2) .+ sqrt.((A .- B′).^2 .+ (B .+ A′).^2)), dims=1))./interval(2)
            if o == 1
                sω += interval(2)*sum(wmod.*sqrt.(E[rre,1].^2 .+ E[rim,1].^2))
            end
        end
        GC.gc()
    end
    # Divide by each input weight, then take the largest column norm; see (5.4).
    wJ = vcat([w[ind(n)] for n = nsJ]...)
    Z1_0 = maximum([Z1_0 ; s./wJ ; (o == 1 ? [sω] : Interval{Float64}[])])
end
println("Bound Z_{1,0} : Z1_0 = $Z1_0")

# Bound the multiplication leakage π^{>N} M_V π^{≤N} needed in Z_{1,1}.
# 𝒯 stores upper bounds for the normalized column norms (Lemma 5.2).
wN = weight_nu(ν,N2) ; wNV = weight_nu(ν,N2+NV2)
𝒯 = interval.(zeros(dd+1))
for k = filter(iseven, -NV1:NV1)
    Mk = coefficients(MV[k])
    # A retained output Fourier mode contributes only its radial tail.
    # An output Fourier mode outside the finite block contributes its entire radial series.
    c_out = norm_cols(Mk[d2+1:end,:], wNV[d2+1:end], wN) ; c_all = norm_cols(Mk, wNV, wN)
    for m = -N1:2:N1
        𝒯[ind(m)] += νθ^interval(abs(m+k)-abs(m))*(abs(m+k) <= N1 ? c_out : c_all)
    end
end

# Finite column norms for (5.28), and the multiplication term in Z_{1,1}.
# Reuse the complex columns of A_N; negative-mode norms follow by symmetry.
wW = [interval(0) ; w[2:end]]
# Multiplication by n² gives the weights for 𝒩²π_W A_N.
wq = wW.*[interval(0) ; vec([interval(n)^2 for k = 0:N2, n = -N1:2:N1])]
# Start with the frequency input column.
cω = interval.(BN[:,1])
z = zeros(Complex{Interval{Float64}}, dd+1)
z[1] = cω[1]
for m = 1:2:N1
    z[ind(m)] = cω[ia(m)] + interval(im)*cω[ib(m)] ; z[ind(-m)] = cω[ia(m)] - interval(im)*cω[ib(m)]
end
norm_πW_A = sum(abs.(wW.*z)) ; norm_πω_A = abs(z[1]) ; norm_𝒩²πW_A = sum(abs.(wq.*z)) ; Z1_1 = sum(abs.(w.*𝒯.*z))
norm_∂ωΛπW_A = sum(sum(abs.(w[ind(m)].*(dΛN(m)*z[ind(m)]))) for m = -N1:2:N1)
# Then include every positive Fourier input column, using (5.4).
for ns = blkp
    global norm_πW_A, norm_πω_A, norm_𝒩²πW_A, Z1_1, norm_∂ωΛπW_A
    Z = A_cols(ns) ; wn = vcat([w[ind(n)] for n = ns]...)
    norm_πW_A = maximum([norm_πW_A ; norm_cols(Z, wW, wn)])
    norm_πω_A = maximum([norm_πω_A ; abs.(Z[1,:])./wn])
    norm_𝒩²πW_A = maximum([norm_𝒩²πW_A ; norm_cols(Z, wq, wn)])
    Z1_1 = maximum([Z1_1 ; norm_cols(Z, w.*𝒯, wn)])
    # Apply ∂ωΛ to each output Fourier block before summing its column norm.
    sp = interval.(zeros(size(Z,2)))
    for m = -N1:2:N1
        sp += vec(sum(abs.(w[ind(m)].*(dΛN(m)*Z[ind(m),:])), dims=1))
    end
    norm_∂ωΛπW_A = maximum([norm_∂ωΛπW_A ; sp./wn])
    GC.gc()
end

# Complete Z_{1,1} with the frequency-column tail and the omitted potential (Lemma 5.2).
# The frequency-column tail vanishes when the candidate support lies inside N.
Z1_1 = Z1_1 + norm_πω_A*norm_dΛW_out + norm_πW_A*norm_pWp1_V
println("Bound Z_{1,1} : Z1_1 = $Z1_1")

println("‖π_W A_N‖ ≤ $norm_πW_A ,  ‖π_ω A_N‖ ≤ $norm_πω_A ,  ‖∂ωΛ π_W A_N‖ ≤ $norm_∂ωΛπW_A ,  ‖𝒩² π_W A_N‖ ≤ $norm_𝒩²πW_A")
# Add the exterior columns, where A=Λ^(-1), using (4.18) and (5.28).
# κ, κ′ and κ′′ are supplied by Lemmas 5.7 and 5.9.
norm_πW_A = maximum([norm_πW_A κ]) ; norm_∂ωΛπW_A = maximum([norm_∂ωΛπW_A κ′]) ; norm_𝒩²πW_A = maximum([norm_𝒩²πW_A κ′′])

# Combine finite-input and exterior-input defects: Z1=max(Z1_0+Z1_1,Z1_2), Lemma 5.2.
Z1 = maximum([Z1_0+Z1_1 Z1_2])
println("Bound Z1 : Z1 = $Z1")

# Z2: Section 5.4, Lemma 5.8.
# Evaluate the nondecreasing bound at 10^(-6); the validated radius must lie below it.
r_Z2 = interval(1)/interval(1000000)

# Use the computed norms of W^m for the nonlinear term in Lemma 5.8.
# The remaining terms account for the mixed and quadratic frequency dependence in (5.27).
Z2 = interval(p)*sum(interval(binomial(p-1,j))*norm_Wm[p-j]*norm_πW_A^(j+1)*r_Z2^(j-1) for j = 1:p-1) + interval(2)*norm_πω_A*norm_∂ωΛπW_A + norm_πω_A^2*(interval(2)*norm_𝒩²W + interval(3)*norm_𝒩²πW_A*r_Z2)

# Alternative Banach-algebra bound: replace each ‖W^m‖ by ‖W‖^m.
Z2_W = interval(p)*interval(p-1)*norm_πW_A^2*(norm_W + norm_πW_A*r_Z2)^(p-2) + interval(2)*norm_πω_A*norm_∂ωΛπW_A + norm_πω_A^2*(interval(2)*norm_𝒩²W + interval(3)*norm_𝒩²πW_A*r_Z2)
# Both expressions bound Z2(r) on r≤r_Z2; retain the smaller one.
Z2 = min(Z2, Z2_W)
println("Bound Z2 : Z2 = $Z2")

# Radius certificate: Section 5.5, Theorem 4.5 and conditions (4.15).
# Z1<1 also gives injectivity of A by Lemma 5.10.
# This block verifies one radius; Theorem 5.11 also states an interval of admissible radii.
(sup(Z1) < 1)&&(inf((interval(1)-Z1)^2) > sup(interval(2)*Z2*Y)) ||
    error("The radii-polynomial discriminant condition was not verified.")

# Construct a trial radius from the scalar quadratic, then verify it with intervals.
r0 = (1 - sup(big(Z1)) - sqrt( (1-sup(big(Z1)))^2 - 2*sup(big(Z2))*sup(Y) ) )/inf(Z2)
r0 = interval(r0)

# Invariance and contraction inequalities from (4.15).
p1 = I"0.5"*Z2*r0^2 - (I"1" - Z1)*r0 + Y
p2 = Z1 + Z2*r0

# Also check r0≤r_Z2, hypotheses (5.11)–(5.12), and every inverse defect ε_n<1.
# These are the assumptions used by Lemmas 5.7 and 5.9.
(sup(p1) < 0)&&(sup(p2) < 1)&&(sup(r0)<inf(r_Z2))&&H&&(sup(ε_max) < 1) ||
    error("The radius or inverse validation conditions were not verified.")
sup_r = Float64(sup(r0),RoundUp)
println("  ✓ EXISTENCE PROVEN : a real zero (ω*,W*) of F exists near the approximate solution, (d,p) = ($d,$p).")
println("    Newton–Kantorovich bounds :  Y  = $(sup(Y))")
println("                                 Z₁ = $(sup(Z1))")
println("                                 Z₂ = $(sup(Z2))")
println("    Validated radius          :  r₀ = $sup_r")
# r0 bounds Ψ in U=Ū+AΨ; component norms of A give the errors in (5.31).
println("    ⇒ |ω* - ω| ≤ $(Float64(sup(norm_πω_A*r0),RoundUp))  and  ‖W* - W‖ ≤ $(Float64(sup(norm_πW_A*r0),RoundUp)).")

# Uniform profile-size bounds: Remark 5.13.
# Combined with the validated error, these give the cone blow-up rate via Proposition 2.4.
M = 2000

# Return to the paper convention: w_k=2a_k for k≥1.
# Enclose each positive-mode coefficient in Float64; negative modes are its conjugates.
w = [interval(Float64(inf(real(c)),RoundDown),Float64(sup(real(c)),RoundUp)) + interval(im)*interval(Float64(inf(imag(c)),RoundDown),Float64(sup(imag(c)),RoundUp)) for c = [interval(k == 0 ? 1 : 2)*W[(2*j-1,k)] for j = 1:div(NW1+1,2), k = 0:NW2]]

# Endpoint traces: T_k(1)=1 at ρ=1 and T_k(−1)=(−1)^k at ρ=0.
V1 = [sum(w[j,:]) for j = 1:div(NW1+1,2)]
V0 = [sum(w[j,1:2:end]) - sum(w[j,2:2:end]) for j = 1:div(NW1+1,2)]

# |T_k|≤1 gives S≥|W| and L≥|∂θW| on real θ and 0≤ρ≤1 (Remark 5.13).
S = interval(2)*sum(abs.(w))
L = interval(2)*sum(interval.(1:2:NW1).*vec(sum(abs.(w), dims=2)))

# Evaluate the endpoint traces on 2001 points of [0,π].
# Half-period antisymmetry makes this interval sufficient.
Wθ(V,θ) = interval(2)*sum(real(V[j])*cos(interval(2*j-1)*θ) - imag(V[j])*sin(interval(2*j-1)*θ) for j = 1:div(NW1+1,2))
m = S
for i = 0:M
    global m
    θ = interval(i)*interval(π)/interval(M)
    m = min(m, max(abs(Wθ(V0,θ)), abs(Wθ(V1,θ))))
end

# Every θ is within π/(2M) of a grid point; subtract the Lipschitz correction.
m = m - L*interval(π)/interval(2*M)

println("Lipschitz constant in θ : L = $L")
# Transfer the validated error δ_W=‖π_W A‖r0 to the uniform profile bounds.
δ = norm_πW_A*r0
println("For all θ :  max(|W*(θ,0)|, |W*(θ,1)|) ≥ $(Float64(inf(m - δ),RoundDown))  and  |W*(θ,ρ)| ≤ $(Float64(sup(S + δ),RoundUp)) for all ρ ∈ [0,1]")
